/* odb/mysql/details/config.h.  Generated from config.h.in by configure.  */
/* file      : odb/mysql/details/config.h.in
 * copyright : Copyright (c) 2009-2015 Code Synthesis Tools CC
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

/* This file is automatically processed by configure. */

#ifndef ODB_MYSQL_DETAILS_CONFIG_H
#define ODB_MYSQL_DETAILS_CONFIG_H

/* #undef LIBODB_MYSQL_STATIC_LIB */

/* #undef LIBODB_MYSQL_INCLUDE_SHORT */
#define LIBODB_MYSQL_INCLUDE_LONG 1

#define LIBODB_MYSQL_THR_KEY_VISIBLE 1

#endif /* ODB_MYSQL_DETAILS_CONFIG_H */
