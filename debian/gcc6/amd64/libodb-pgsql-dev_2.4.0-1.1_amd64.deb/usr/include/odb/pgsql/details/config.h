/* odb/pgsql/details/config.h.  Generated from config.h.in by configure.  */
/* file      : odb/pgsql/details/config.h.in
 * copyright : Copyright (c) 2009-2015 Code Synthesis Tools CC
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

/* This file is automatically processed by configure. */

#ifndef ODB_PGSQL_DETAILS_CONFIG_H
#define ODB_PGSQL_DETAILS_CONFIG_H

/* #undef LIBODB_PGSQL_STATIC_LIB */

#endif /* ODB_PGSQL_DETAILS_CONFIG_H */
