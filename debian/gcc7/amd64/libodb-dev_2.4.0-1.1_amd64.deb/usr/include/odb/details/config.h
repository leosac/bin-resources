/* odb/details/config.h.  Generated from config.h.in by configure.  */
/* file      : odb/details/config.h.in
 * copyright : Copyright (c) 2009-2015 Code Synthesis Tools CC
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

/* This file is automatically processed by configure. */

#ifndef ODB_DETAILS_CONFIG_H
#define ODB_DETAILS_CONFIG_H

/* #undef ODB_THREADS_NONE */
#define ODB_THREADS_POSIX 1
/* #undef ODB_THREADS_WIN32 */
#define ODB_THREADS_TLS_KEYWORD 1
/* #undef ODB_THREADS_TLS_DECLSPEC */

/* #undef LIBODB_STATIC_LIB */

#endif /* ODB_DETAILS_CONFIG_H */
