// file      : odb/sqlite/prepared-query.cxx
// copyright : Copyright (c) 2005-2015 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/sqlite/prepared-query.hxx>

namespace odb
{
  namespace sqlite
  {
    prepared_query_impl::
    ~prepared_query_impl ()
    {
    }
  }
}
