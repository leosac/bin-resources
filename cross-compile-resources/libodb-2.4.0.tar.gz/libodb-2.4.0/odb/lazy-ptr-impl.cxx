// file      : odb/lazy-ptr-impl.cxx
// copyright : Copyright (c) 2009-2015 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/lazy-ptr-impl.hxx>

namespace odb
{
  // This otherwise unnecessary file is here to allow instantiation
  // of inline functions for exporting.
}
